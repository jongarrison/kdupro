# Kduino Data Analysis



Kduino data analysis is a python module designed for open and analyze data files from Kduino instrumentation. Also, provide methods to generate plots and convert data files in netCDF and CSV format.

This module works with different versions of Kduino:
- Kdupro
- Kdustick
- Kdumod (in development)



## Installation

Clone this repository in your local system (`git clone git@git.csic.es:kduino/kduino-data-analysis.git`) and then launch the `main.py` file to run the Kduino Data Analysis.

## Usage

You need to add your data file inside `data` folder and create a new configuration file inside the properties folder. There is a template and so many examples to create your own configuration. 


## License

[MIT](LICENSE)

<p align="center">
<img width="150" src="./docs/img_docs/logo.png">
</p>

This project has received funding from the European Union's Horizon 2020 research and innovation programme under grant agreement No 776480 (MONOCLE).